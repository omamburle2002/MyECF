from django.contrib import admin
from control.models import myecf,userFeedback


# Register your models here.

admin.site.register(myecf)
admin.site.register(userFeedback)